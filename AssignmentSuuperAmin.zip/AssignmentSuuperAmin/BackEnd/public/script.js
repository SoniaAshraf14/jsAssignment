const form = document.getElementById('uploadForm');
const gallery = document.getElementById('gallery');
const userSelect = document.getElementById('userSelect');
const formUserInput = document.getElementById('formUser'); // hidden input

let currentUser = userSelect.value;

userSelect.addEventListener('change', () => {
  currentUser = userSelect.value;
  formUserInput.value = currentUser;
  loadImages();
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  formUserInput.value = currentUser; // Ensure formData includes selected user

  const formData = new FormData(form);
  try {
    const res = await fetch('/upload', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    alert(data.message || 'Upload completed');
    form.reset();
    loadImages();
  } catch (error) {
    alert('Upload failed');
  }
});

async function loadImages() {
  gallery.innerHTML = '';
  const viewer = currentUser;
  const viewUsers = currentUser === 'superadmin'
    ? ['superadmin', 'user1', 'user2', 'user3']
    : [currentUser];

  for (const user of viewUsers) {
    const res = await fetch(`/images/${user}?viewer=${viewer}`);
    const files = await res.json();

    const section = document.createElement('div');
    section.innerHTML = `<h3>${user}'s Images</h3>`;
    files.forEach(file => {
      const card = document.createElement('div');
      card.className = 'image-card';

      const img = document.createElement('img');
      img.src = file;
      img.width = 150;
      card.appendChild(img);

      const fileName = file.split('/').pop();

      if (user === currentUser) {
        const btn = document.createElement('button');
        btn.innerText = 'Delete';
        btn.onclick = () => deleteImage(user, fileName);
        card.appendChild(btn);
      }

      section.appendChild(card);
    });

    gallery.appendChild(section);
  }
}

async function deleteImage(user, fileName) {
  const confirmed = confirm('Are you sure you want to delete this image?');
  if (!confirmed) return;

  try {
    const res = await fetch(`/delete/${user}/${fileName}?user=${currentUser}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    alert(data.message || data.error);
    loadImages();
  } catch (err) {
    alert('Error deleting image');
  }
}

formUserInput.value = currentUser; // Set default user in form
loadImages();
