const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 8000;

app.use(cors());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use(express.json());

const USERS = ['superadmin', 'user1', 'user2', 'user3'];

// Multer storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const user = req.body.user; // <-- here body is not available yet unless handled properly
    if (!user) {
      return cb(new Error('User field is missing'));
    }
    const uploadPath = path.join(__dirname, 'uploads', user);
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

app.post('/upload', upload.single('image'), (req, res) => {
  const user = req.body.user;
  if (!USERS.includes(user)) {
    return res.status(400).json({ error: 'Invalid user' });
  }
  res.json({ message: 'Image uploaded successfully' });
});

app.get('/images/:user', (req, res) => {
  const requestedUser = req.params.user;
  const queryUser = req.query.viewer;

  if (!USERS.includes(requestedUser) || !USERS.includes(queryUser)) {
    return res.status(400).json({ error: 'Invalid user' });
  }

  if (queryUser !== requestedUser && queryUser !== 'superadmin') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const dirPath = path.join(__dirname, 'uploads', requestedUser);
  if (!fs.existsSync(dirPath)) {
    return res.json([]);
  }

  const files = fs.readdirSync(dirPath);
  res.json(files.map(file => `/uploads/${requestedUser}/${file}`));
});

app.delete('/delete/:user/:filename', (req, res) => {
  const fileOwner = req.params.user;
  const file = req.params.filename;
  const requestUser = req.query.user;

  if (!USERS.includes(fileOwner) || !USERS.includes(requestUser)) {
    return res.status(400).json({ error: 'Invalid user' });
  }

  if (fileOwner !== requestUser) {
    return res.status(403).json({ error: 'Not allowed to delete this file' });
  }

  const filePath = path.join(__dirname, 'uploads', fileOwner, file);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    res.json({ message: 'File deleted' });
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
